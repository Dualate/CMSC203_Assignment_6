
public enum TYPE {
	COFFEE,
	ALCOHOL,
	SMOOTHIE
}
