
public abstract class Beverage {
	private String name;
	private TYPE type;
	private SIZE size;
	final private double price = 2.0;
	final private double size_price = 1.0;
	
	public Beverage(String name, TYPE type, SIZE size) {
		this.name = name;
		this.type = type;
		this.size = size;
	}
	
	public void setBevName(String name) {
		this.name = name;
	}
	
	public void setType(TYPE type) {
		this.type = type;
	}
	
	public void setSize(SIZE size) {
		this.size = size;
	}
	
	public String getBevName() {
		return name;
	}
	
	public TYPE getType() {
		return type;
	}
	
	public SIZE getSize() {
		return size;
	}
	
	public double getBasePrice() {
		return price;
	}
	
	public abstract double calcPrice();
	
	public boolean equals(Beverage drink) {
		if (this.name.equals(drink.getBevName())) {
			if (this.type.equals(drink.getType())) {
				if (this.size.equals(drink.getSize()))
					return true;
			}
		}
		return false;
	}
	
	public String toString() {
		return "Name: " + this.name + ", Size: " + this.size + ", Price: $" + (this.price + this.size_price);
	}
}
