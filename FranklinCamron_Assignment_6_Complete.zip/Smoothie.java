
public class Smoothie extends Beverage {
	private int fruits;
	private boolean protein;
	
	public Smoothie(String name, SIZE size, int fruits, boolean protein) {
		super(name, TYPE.SMOOTHIE, size);
		this.fruits = fruits;
		this.protein = protein;
	}
	
	public void setNumFruits(int fruits) {
		this.fruits = fruits;
	}
	
	public void setProtein(boolean protein) {
		this.protein = protein;
	}
	
	public int getNumOfFruits() {
		return fruits;
	}
	
	public boolean getAddProtein() {
		return protein;
	}
	
	public double calcPrice() {
		double price = 0;
		price += fruits * .5;
		if (protein)
			price += 1.5;
		if (this.getSize() == SIZE.MEDIUM)
			price += 1;
		if (this.getSize() == SIZE.LARGE)
			price += 2;
		price += getBasePrice();
		return price;
	}
	
	public String toString() {
		return "Name: " + getBevName() + ", Size: " + getSize() + ", Type: " + getType() + ", Fruits: " + getNumOfFruits() + ", Protein: " + getAddProtein() + ", Price: $" + calcPrice();
	}
	
	public boolean equals(Smoothie drink) {
		if (drink.getAddProtein() == protein) {
			if (drink.getNumOfFruits() == fruits) {
				if (equals(drink))
					return true;
			}
		}
		return false;
	}
	
}
