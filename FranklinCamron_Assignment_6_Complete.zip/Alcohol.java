
public class Alcohol extends Beverage {
	private boolean weekend;
	
	public Alcohol(String name, SIZE size, boolean status) {
		super(name, TYPE.ALCOHOL, size);
		weekend = status;
	}
	
	public void setWeekend(boolean weekend) {
		this.weekend = weekend;
	}
	
	public boolean getWeekend() {
		return weekend;
	}
	
	public boolean equals(Alcohol drink) {
		if (drink.getWeekend() == this.weekend) {
			if (equals(drink))
				return true;
		}
		return false;
	}
	
	public double calcPrice() {
		double price = 0.0;
		if (weekend)
			price += .6;
		if (this.getSize() == SIZE.MEDIUM)
			price += 1;
		if (this.getSize() == SIZE.LARGE)
			price += 2;
		price += getBasePrice();
		return price;
	}
	
	public String toString() {
		return "Name: " + getBevName() + ", Size: " + getSize() + ", Type: " + getType() + ", Price: $" + calcPrice();
	}
}
