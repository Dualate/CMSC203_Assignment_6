
public class Coffee extends Beverage {
	private boolean extracoffee;
	private boolean extrasyrup;
	
	public Coffee(String name, SIZE size, boolean extracoffee, boolean extrasyrup) {
		super(name, TYPE.COFFEE, size);
		this.extracoffee = extracoffee;
		this.extrasyrup = extrasyrup;
	}
	
	public void setCoffeeShot(boolean extrashot) {
		this.extracoffee = extrashot;
	}
	
	public void setSyrupShot(boolean extrasyrup) {
		this.extrasyrup = extrasyrup;
	}
	
	public boolean getExtraShot() {
		return this.extracoffee;
	}
	
	public boolean getExtraSyrup() {
		return this.extrasyrup;
	}
	
	public double calcPrice() {
		double price = 0.0;
		if (this.extracoffee)
			price += .5;
		if (this.extrasyrup)
			price += .5;
		if (this.getSize() == SIZE.MEDIUM)
			price += 1;
		if (this.getSize() == SIZE.LARGE)
			price += 2;
		price += getBasePrice();
		return price;
	}
	
	public boolean equals(Coffee drink) {
		
		if (this.extracoffee == drink.getExtraShot()) {
			if (this.extrasyrup == drink.getExtraSyrup()) {
				if (equals(drink))
					return true;
			}
		}
		return false;
	}
	
	public String toString() {
		return "Name: " + getBevName() + ", Size: " + getSize() + ", Type: " + getType() + ", ExtraShot: " + getExtraShot() + ", ExtraSyrup: " + getExtraSyrup() + ", Price: $" + calcPrice();
	}
	
}
