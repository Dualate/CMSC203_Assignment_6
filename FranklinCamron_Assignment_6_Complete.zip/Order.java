import java.util.ArrayList;
import java.util.Random;
public class Order implements OrderInterface, Comparable<Order>{
	private ArrayList<Beverage> drinklist = new ArrayList();
	private int time;
	private DAY day;
	private Customer person;
	private int number;
	
	public Order(int time, DAY day, Customer person) {
		this.time = time;
		this.day = day;
		this.person = new Customer(person);
		number = getRandom();
	}
	
	public Beverage getBeverage(int index) {
		return drinklist.get(index);
	}
	
	public boolean isWeekend() {
		if (day == DAY.SATURDAY || day == DAY.SUNDAY)
			return true;
		return false;
	}
	
	public int getRandom() {
		Random number = new Random();
		return number.nextInt(90000 - 10000 + 1) + 10000;
	}
	
	public void addNewBeverage (String name, SIZE size, boolean extrashot, boolean extrasyrup) {
		drinklist.add(new Coffee(name, size, extrashot, extrasyrup));
	}
	
	public void addNewBeverage (String name, SIZE size) {
		boolean status = false;
		if (isWeekend())
			status = true;
		drinklist.add(new Alcohol(name, size, status));
	}
	
	public void addNewBeverage (String name, SIZE size, int fruit, boolean protein) {
		drinklist.add(new Smoothie(name, size, fruit, protein));
	}
	
	public String toString() {
		String order = "";
		order += Integer.toString(getOrderNo()) + "\n";
		order += person.getName() + ", " + Integer.toString(person.getAge());
		for (int i = 0; i < drinklist.size(); i++) {
			order = order + drinklist.get(i).toString() + "\n";
		}
		order += "Order total: $" + calcOrderTotal() + "\n";
		return order;
	}
	
	public int getOrderNo() {
		return number;
	}
	
	public int getOrderTime() {
		return time;
	}
	
	public DAY getOrderDay() {
		return day;
	}
	
	public int compareTo(Order order) {
		if (this.number == order.getOrderNo())
			return 0;
		else if (this.number > order.getOrderNo())
			return 1;
		else
			return -1;
	}
	
	public int getTotalItems() {
		return drinklist.size();
	}
	
	public double calcOrderTotal() {
		double total = 0;
		for (int i = 0; i < drinklist.size(); i++)
			total += drinklist.get(i).calcPrice();
		return total;
	}
	
	public int findNumOfBeveType(TYPE type) {
		int total = 0;
		for (int i = 0; i < drinklist.size(); i++) {
			if (drinklist.get(i).getType() == type)
				total += 1;
		}
		return total;
	}
	
	public Customer getCustomer() {
		return new Customer(this.person.getName(), this.person.getAge());
	}

}
