import java.util.ArrayList;

public class BevShop implements BevShopInterfce {
	
	private ArrayList<Order> orders = new ArrayList();
	private int drinks;
	private int current_index = 0;
	private boolean flag = false;
	public boolean validTime(int time) {
		if (time >= 8) {
			if (time <= 23) {
				return true;
			}
		}
		return false;
	}
	
	public boolean validAge(int age) {
		if (age > MIN_AGE_FOR_ALCOHOL)
			return true;
		else
			return false;
	}
	
	public int getMinAgeForAlcohol() {
		return MIN_AGE_FOR_ALCOHOL;
	}
	
	public int getMaxOrderForAlcohol() {
		return MAX_ORDER_FOR_ALCOHOL;
	}
	public void processCoffeeOrder(String name, SIZE size, boolean extrashot, boolean extrasyrup) {
		orders.get(current_index).addNewBeverage(name, size, extrashot, extrasyrup);
	}
	
	public void processSmoothieOrder(String name, SIZE size, int fruits, boolean protein) {
		orders.get(current_index).addNewBeverage(name, size, fruits, protein);
	}
	
	public void processAlcoholOrder(String name, SIZE size) {
		orders.get(current_index).addNewBeverage(name, size);
	}
	
	public int findOrder(int orderNo) {
		for (int i = 0; i < orders.size(); i++) {
			if (orders.get(i).getOrderNo() == orderNo)
				return i;
		}
		return -1;
	}
	
	public double totalOrderPrice(int num) {
		int index = findOrder(num);
		return orders.get(index).calcOrderTotal();
	}
	
	public double totalMonthlySale() {
		double total = 0;
		for (int i = 0; i < orders.size(); i++)
			total += orders.get(i).calcOrderTotal();
		return total;
	}
	
	public void sortOrders() {
		int start, index, minIndex;
		Order minOrder;
		for (start = 0; start < orders.size() - 1; start++) {
			minIndex = start;
			minOrder = orders.get(start);
			for (index = start; index < orders.size(); index++) {
				if (orders.get(index).getOrderNo() < minOrder.getOrderNo()) {
					minOrder = orders.get(index);
					minIndex = index;
				}
			}
			orders.set(minIndex, orders.get(start));
			orders.set(start, minOrder);
		}
	}
	
	public Order getCurrentOrder() {
		return orders.get(current_index);
	}
	
	public void startNewOrder(int time, DAY day, String name, int age) {
		orders.add(new Order(time, day, new Customer(name, age)));
		if (current_index == 0 && flag == false)
			flag = true;
		else
			current_index++;
	}
	
	public boolean eligibleForMore() {
		if (orders.get(current_index).findNumOfBeveType(TYPE.ALCOHOL) == MAX_ORDER_FOR_ALCOHOL)
			return false;
		return true;
	}
	
	public Order getOrderAtIndex(int index) {
		return orders.get(index);
	}
	
	public boolean isMaxFruit(int fruits) {
		if (fruits == 6)
			return true;
		else
			return false;
	}
	
	public int totalNumOfMonthlyOrders() {
		return orders.size();
	}
	
	public int getNumOfAlcoholDrink() {
		return orders.get(current_index).findNumOfBeveType(TYPE.ALCOHOL); 
	}
	
	
	@Override
	public String toString() {
		String bevshop = "";
		for (int i = 0; i < orders.size(); i++)
			bevshop += orders.get(i).toString() + "\n";
		bevshop += "Total Monthly Sales: $" + totalMonthlySale() + "\n";
		return bevshop;
	}
	
}
